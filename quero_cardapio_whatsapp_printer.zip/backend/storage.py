import json
import os
import sqlite3
from datetime import datetime, date
from typing import Any, Dict, List, Tuple

from openpyxl import Workbook


def init_db(db_path: str) -> None:
    conn = sqlite3.connect(db_path)
    try:
        cur = conn.cursor()
        cur.execute(
            """
            CREATE TABLE IF NOT EXISTS orders (
              id INTEGER PRIMARY KEY AUTOINCREMENT,
              created_at TEXT NOT NULL,
              day TEXT NOT NULL,
              order_prefix TEXT NOT NULL,
              order_no INTEGER NOT NULL,
              customer_name TEXT NOT NULL,
              customer_phone TEXT NOT NULL,
              customer_address TEXT NOT NULL,
              payment_method TEXT NOT NULL,
              note TEXT,
              items_json TEXT NOT NULL,
              totals_json TEXT NOT NULL,
              total REAL NOT NULL
            );
            """
        )
        cur.execute("CREATE INDEX IF NOT EXISTS idx_orders_day ON orders(day);")
        cur.execute("CREATE UNIQUE INDEX IF NOT EXISTS idx_orders_day_no ON orders(day, order_no);")
        conn.commit()
    finally:
        conn.close()


def _next_order_no(conn: sqlite3.Connection, day_iso: str) -> int:
    cur = conn.cursor()
    cur.execute("SELECT COALESCE(MAX(order_no), 0) + 1 FROM orders WHERE day = ?", (day_iso,))
    return int(cur.fetchone()[0])


def insert_order(db_path: str, created_at: datetime, prefix: str, payload: Dict[str, Any]) -> Tuple[int, int]:
    day_iso = created_at.date().isoformat()
    conn = sqlite3.connect(db_path)
    try:
        order_no = _next_order_no(conn, day_iso)
        cur = conn.cursor()

        items_json = json.dumps(payload.get("items", []), ensure_ascii=False)
        totals_json = json.dumps(payload.get("totals", {}), ensure_ascii=False)
        total = float(payload.get("totals", {}).get("total", 0.0))

        cur.execute(
            """
            INSERT INTO orders (
              created_at, day, order_prefix, order_no,
              customer_name, customer_phone, customer_address,
              payment_method, note,
              items_json, totals_json, total
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                created_at.isoformat(sep=" ", timespec="seconds"),
                day_iso,
                prefix,
                order_no,
                payload.get("customer_name", ""),
                payload.get("customer_phone", ""),
                payload.get("customer_address", ""),
                payload.get("payment_method", ""),
                payload.get("note", ""),
                items_json,
                totals_json,
                total,
            ),
        )
        conn.commit()
        return int(cur.lastrowid), order_no
    finally:
        conn.close()


def list_orders_by_date(db_path: str, d: date) -> List[Dict[str, Any]]:
    day_iso = d.isoformat()
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    try:
        cur = conn.cursor()
        cur.execute("SELECT * FROM orders WHERE day = ? ORDER BY order_no ASC", (day_iso,))
        rows = cur.fetchall()
        out = []
        for r in rows:
            out.append(
                {
                    "id": r["id"],
                    "created_at": r["created_at"],
                    "day": r["day"],
                    "order_prefix": r["order_prefix"],
                    "order_no": r["order_no"],
                    "customer_name": r["customer_name"],
                    "customer_phone": r["customer_phone"],
                    "customer_address": r["customer_address"],
                    "payment_method": r["payment_method"],
                    "note": r["note"] or "",
                    "items": json.loads(r["items_json"]),
                    "totals": json.loads(r["totals_json"]),
                    "total": r["total"],
                }
            )
        return out
    finally:
        conn.close()


def sum_day(orders: List[Dict[str, Any]]) -> Dict[str, Any]:
    total_orders = len(orders)
    total_value = sum(float(o.get("total", 0.0)) for o in orders)
    items_map: Dict[str, Dict[str, Any]] = {}
    pay_map: Dict[str, float] = {}

    for o in orders:
        pay = o.get("payment_method", "N/I")
        pay_map[pay] = pay_map.get(pay, 0.0) + float(o.get("total", 0.0))
        for it in o.get("items", []):
            key = it.get("name", "Item")
            if key not in items_map:
                items_map[key] = {"name": key, "qty": 0, "value": 0.0}
            items_map[key]["qty"] += int(it.get("qty", 0))
            items_map[key]["value"] += float(it.get("price", 0.0)) * int(it.get("qty", 0))

    items_sorted = sorted(items_map.values(), key=lambda x: (-x["qty"], x["name"]))
    return {
        "total_orders": total_orders,
        "total_value": total_value,
        "by_payment": pay_map,
        "items": items_sorted,
    }


def export_day_xlsx(db_path: str, d: date) -> str:
    orders = list_orders_by_date(db_path, d)
    out_dir = os.path.join(os.path.dirname(db_path), "exports")
    os.makedirs(out_dir, exist_ok=True)
    path = os.path.join(out_dir, f"fechamento_{d.isoformat()}.xlsx")

    wb = Workbook()
    ws = wb.active
    ws.title = "Pedidos"

    headers = [
        "NumeroPedido",
        "DataHora",
        "Nome",
        "Celular",
        "Endereco",
        "Pagamento",
        "Itens",
        "Observacao",
        "Total",
        "Origem",
    ]
    ws.append(headers)

    for o in orders:
        itens_str = " | ".join([f"{it['qty']}x {it['name']}" for it in o.get("items", [])])
        ws.append(
            [
                o.get("order_no"),
                o.get("created_at"),
                o.get("customer_name"),
                o.get("customer_phone"),
                o.get("customer_address"),
                o.get("payment_method"),
                itens_str,
                o.get("note", ""),
                float(o.get("total", 0.0)),
                o.get("order_prefix", "WhatsApp"),
            ]
        )

    wb.save(path)
    return path
