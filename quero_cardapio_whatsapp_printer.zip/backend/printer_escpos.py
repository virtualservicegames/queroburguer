"""
Impressão ESC/POS (Bematech MP-4200 TH)
- Envia bytes crus para a impressora no Windows (spooler)
"""

from datetime import datetime, date
from typing import Any, Dict

try:
    import win32print  # pywin32
except Exception:
    win32print = None

ESC = b"\x1b"
GS  = b"\x1d"


def _esc_init() -> bytes:
    return ESC + b"@"


def _esc_align(n: int) -> bytes:
    return ESC + b"a" + bytes([n])


def _esc_bold(on: bool) -> bytes:
    return ESC + b"E" + (b"\x01" if on else b"\x00")


def _esc_size(w: int, h: int) -> bytes:
    w = max(1, min(8, w))
    h = max(1, min(8, h))
    n = ((w - 1) << 4) | (h - 1)
    return GS + b"!" + bytes([n])


def _esc_cut() -> bytes:
    return GS + b"V" + b"\x00"


def _line(text: str = "") -> bytes:
    return (text + "\n").encode("cp860", errors="replace")


def _hr() -> bytes:
    return _line("-" * 42)


def _send_raw(printer_name: str | None, data: bytes) -> None:
    if win32print is None:
        raise RuntimeError("pywin32 não instalado. Instale: pip install pywin32")

    p = printer_name or win32print.GetDefaultPrinter()
    h = win32print.OpenPrinter(p)
    try:
        job = win32print.StartDocPrinter(h, 1, ("Pedido WhatsApp", None, "RAW"))
        try:
            win32print.StartPagePrinter(h)
            win32print.WritePrinter(h, data)
            win32print.EndPagePrinter(h)
        finally:
            win32print.EndDocPrinter(h)
    finally:
        win32print.ClosePrinter(h)


def _brl(v: float) -> str:
    return f"R$ {v:,.2f}".replace(",", "X").replace(".", ",").replace("X", ".")


def print_order_receipt(printer_name: str | None, order_prefix: str, order_no: int, created_at: datetime, payload: Dict[str, Any]) -> None:
    items = payload.get("items", [])
    totals = payload.get("totals", {})
    note = (payload.get("note") or "").strip()

    data = b""
    data += _esc_init()
    data += _esc_align(1)
    data += _esc_bold(True) + _esc_size(2, 2)
    data += _line("QUERO BURGUER")
    data += _esc_size(1, 1) + _esc_bold(False)
    data += _line("Pedido Online")
    data += _hr()

    data += _esc_align(0)
    data += _esc_bold(True)
    data += _line(f"{order_prefix} {order_no:06d}")
    data += _esc_bold(False)

    data += _line(f"Data/Hora: {created_at.strftime('%d/%m/%Y %H:%M:%S')}")
    data += _hr()
    data += _line(f"Nome: {payload.get('customer_name','')}")
    data += _line(f"Celular: {payload.get('customer_phone','')}")
    data += _line("Endereco:")
    data += _line(str(payload.get('customer_address','')))
    data += _hr()

    data += _line("ITENS:")
    for it in items:
        qty = int(it.get("qty", 0))
        name = str(it.get("name", ""))
        price = float(it.get("price", 0.0))
        line_total = price * qty
        left = f"{qty}x {name}"
        right = _brl(line_total)
        if len(left) > 28:
            left = left[:28] + "..."
        data += _line(f"{left:<32}{right:>10}")

    data += _hr()
    total = float(totals.get("total", 0.0))
    data += _esc_bold(True)
    data += _line(f"{'TOTAL':<32}{_brl(total):>10}")
    data += _esc_bold(False)
    data += _line(f"Pagamento: {payload.get('payment_method','')}")

    if note:
        data += _hr()
        data += _line("OBS:")
        data += _line(note)

    data += _line("")
    data += _esc_align(1)
    data += _line("Obrigado!")
    data += _line("")
    data += _line("")
    data += _esc_cut()

    _send_raw(printer_name, data)


def print_close_day_receipt(printer_name: str | None, day: date, summary: Dict[str, Any]) -> None:
    data = b""
    data += _esc_init()
    data += _esc_align(1) + _esc_bold(True) + _esc_size(2, 2)
    data += _line("FECHAMENTO")
    data += _esc_size(1, 1) + _esc_bold(False)
    data += _line(f"Dia {day.strftime('%d/%m/%Y')}")
    data += _hr()

    data += _esc_align(0)
    data += _line(f"Pedidos: {summary.get('total_orders',0)}")
    data += _esc_bold(True) + _line(f"Total: {_brl(float(summary.get('total_value',0.0)))}") + _esc_bold(False)
    data += _hr()

    data += _line("Por pagamento:")
    by_pay = summary.get("by_payment", {}) or {}
    for k, v in by_pay.items():
        data += _line(f"- {k}: {_brl(float(v))}")

    data += _hr()
    data += _line("Itens (qtde):")
    for it in summary.get("items", [])[:60]:
        data += _line(f"- {it['qty']}x {it['name']}")

    data += _line("")
    data += _line("")
    data += _esc_cut()
    _send_raw(printer_name, data)
