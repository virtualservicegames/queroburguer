import os
from datetime import datetime, date
from typing import List, Optional

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field

from printer_escpos import print_order_receipt, print_close_day_receipt
from storage import init_db, insert_order, list_orders_by_date, sum_day, export_day_xlsx

APP_TITLE = "Quero Burguer - Impressão WhatsApp"
DB_PATH = os.path.join(os.path.dirname(__file__), "orders.db")

# === CONFIGURAÇÃO DA IMPRESSORA (Windows) ===
PRINTER_NAME = "Bematech MP-4200 TH"  # ajuste se necessário

# Prefixo antes do número da nota (mesma linha)
ORDER_PREFIX = "WhatsApp"


class OrderItem(BaseModel):
    id: str
    name: str
    qty: int = Field(ge=1)
    price: float = Field(ge=0)


class Totals(BaseModel):
    subtotal: float = Field(ge=0)
    fee: float = Field(ge=0)
    total: float = Field(ge=0)


class OrderIn(BaseModel):
    source: str = "WhatsApp"
    customer_name: str
    customer_phone: str
    customer_address: str
    payment_method: str
    note: Optional[str] = ""
    items: List[OrderItem]
    totals: Totals


app = FastAPI(title=APP_TITLE)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"]
)


@app.on_event("startup")
def _startup():
    init_db(DB_PATH)


@app.get("/health")
def health():
    return {"ok": True, "time": datetime.now().isoformat()}


@app.post("/order")
def create_order(order: OrderIn):
    if not order.items:
        raise HTTPException(status_code=400, detail="Pedido sem itens.")
    now = datetime.now()

    new_id, order_no = insert_order(DB_PATH, now, ORDER_PREFIX, order.model_dump())

    try:
        print_order_receipt(
            printer_name=PRINTER_NAME,
            order_prefix=ORDER_PREFIX,
            order_no=order_no,
            created_at=now,
            payload=order.model_dump(),
        )
    except Exception as e:
        return {"ok": False, "id": new_id, "order_no": order_no, "printed": False, "error": str(e)}

    return {"ok": True, "id": new_id, "order_no": order_no, "printed": True}


@app.get("/orders/{yyyy_mm_dd}")
def get_orders_for_day(yyyy_mm_dd: str):
    try:
        d = date.fromisoformat(yyyy_mm_dd)
    except ValueError:
        raise HTTPException(status_code=400, detail="Data inválida. Use YYYY-MM-DD.")
    return {"ok": True, "date": yyyy_mm_dd, "orders": list_orders_by_date(DB_PATH, d)}


@app.post("/close-day")
def close_day():
    today = date.today()
    orders = list_orders_by_date(DB_PATH, today)
    if not orders:
        return {"ok": True, "date": str(today), "message": "Sem vendas no dia."}

    summary = sum_day(orders)
    xlsx_path = export_day_xlsx(DB_PATH, today)

    try:
        print_close_day_receipt(
            printer_name=PRINTER_NAME,
            day=today,
            summary=summary,
        )
    except Exception as e:
        return {"ok": False, "date": str(today), "xlsx_path": xlsx_path, "error": str(e)}

    return {"ok": True, "date": str(today), "xlsx_path": xlsx_path}
