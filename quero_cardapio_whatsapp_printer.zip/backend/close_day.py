"""Fechamento do dia (executar e pronto)."""
from datetime import date
from storage import init_db, list_orders_by_date, sum_day, export_day_xlsx
from printer_escpos import print_close_day_receipt

DB_PATH = "orders.db"
PRINTER_NAME = "Bematech MP-4200 TH"  # ajuste se necessário


def main():
    init_db(DB_PATH)
    today = date.today()
    orders = list_orders_by_date(DB_PATH, today)
    if not orders:
        print("Sem vendas hoje.")
        return
    summary = sum_day(orders)
    xlsx = export_day_xlsx(DB_PATH, today)
    print_close_day_receipt(PRINTER_NAME, today, summary)
    print("Fechamento impresso e planilha gerada em:", xlsx)


if __name__ == "__main__":
    main()
