# Cardápio WhatsApp + Impressão (Bematech MP-4200 TH)

Você terá:
- Site (GitHub Pages) para o cliente montar o pedido
- Servidor Python na loja que RECEBE o pedido, gera número sequencial do dia e IMPRIME automaticamente
- Fechamento do dia: imprime resumo e gera planilha .xlsx

## Por que precisa de TÚNEL HTTPS?
O site do GitHub Pages roda em HTTPS. Por segurança, navegadores bloqueiam enviar (fetch) para `http://localhost`.
Então o servidor da loja precisa ser acessado por uma URL HTTPS.
A forma mais simples é usar Cloudflare Tunnel (gratuito) apontando para o seu PC da loja.

### Cloudflare Tunnel (resumo)
1) Baixe `cloudflared` no PC da loja
2) Rode:
   cloudflared tunnel --url http://localhost:8787
3) Ele vai mostrar uma URL `https://xxxx.trycloudflare.com`
4) Copie essa URL e cole no `ORDER_API_BASE` do `web/index.html`.

## Rodando o servidor (PC da loja - Windows)
Abra o CMD/Powershell na pasta `backend/` e rode:

1) Criar venv:
   python -m venv .venv
2) Ativar:
   .venv\Scripts\activate
3) Instalar:
   pip install -r requirements.txt
4) Rodar:
   uvicorn app:app --host 0.0.0.0 --port 8787

Ele roda só no console.

## Configurar a impressora
Em `backend/app.py`:
- PRINTER_NAME = "Bematech MP-4200 TH"
Se no seu Windows estiver com outro nome, ajuste exatamente igual ao “Dispositivos e Impressoras”.

## Fechamento do dia
Na pasta `backend/`, rode:
   python close_day.py

Ele:
- imprime o fechamento do dia atual (data do computador)
- gera planilha em `backend/exports/fechamento_YYYY-MM-DD.xlsx`

## Publicar o site no GitHub Pages
- Envie o conteúdo da pasta `web/` para a raiz do repositório (index.html e images/)
- Ative GitHub Pages em Settings → Pages

## Nota
A nota imprime a linha pedida por você:
  WhatsApp 000123
